import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class InventoryTest {
    private static Inventory inventory;

    @BeforeAll
    public static void setUp() {
        inventory = new Inventory();
       // inventory.loadInventoryFromFile("D:/test_inventory.txt");
    }
    
    @AfterAll
    public static void tearDown() {
        inventory.saveInventoryToFile("D:/test_inventory.txt");     
    }
    

    @Test
    public void testSaveAndLoadInventory() throws IOException {
        // Adding items to inventory
        inventory.addItemToInventory("Item1", 5);
        inventory.addItemToInventory("Item2", 10);

        // Saving inventory to file
        String fileName = "D:/test_inventory.txt";
        inventory.saveInventoryToFile(fileName);

        // Reset the existing inventory to ensure it's in a clean state
        inventory = new Inventory();
        inventory.loadInventoryFromFile(fileName);

        // Asserting the loaded inventory
        assertEquals(5, inventory.getItemQuantity("Item1"));
        assertEquals(10, inventory.getItemQuantity("Item2"));

        // Clean up: delete the test file
        File file = new File(fileName);
        if (!file.delete()) {
            System.out.println("Failed to delete test file: " + fileName);
        }
    }

    
    @Test
    public void testAddItemToInventory() {
        inventory.addItemToInventory("Gloves", 700);
        inventory.addItemToInventory("Wheelchairs", 10);
        inventory.addItemToInventory("PainKillers", 400); // Adding more to an existing item

        assertEquals(10, inventory.findItem("Wheelchairs").getQuantity());
        assertEquals("Gloves", inventory.findItem("Gloves").getName());
    }
}
