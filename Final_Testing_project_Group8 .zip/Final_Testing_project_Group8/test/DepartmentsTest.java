import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DepartmentsTest {

    @Test
    public void testConstructorAndGetters() {
        // Create a new Departments object
        Departments department = new Departments("Cardiology", 101);

        // Verify the values set by the constructor and getters
        assertEquals("Cardiology", department.getDepartmentName());
        assertEquals(101, department.getdepartmentNumber());
    }

    @Test
    public void testSetters() {
        // Create a new Departments object
        Departments department = new Departments("Orthopedics", 103);

        // Change department name using setter
        department.setDepartmentName("Neurology");
        assertEquals("Neurology", department.getDepartmentName());

        // Change department number using setter
        department.setDepartmentNumber(102);
        assertEquals(102, department.getdepartmentNumber());
    }

    @Test
    public void testInvalidDepartmentName() {
        // Attempt to set an empty department name should throw IllegalArgumentException
        Departments department = new Departments("Pediatrics", 105);
        
        // Verify that setting an empty department name results in an IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            department.setDepartmentName("");
        });
    }

    @Test
    public void testNegativeDepartmentNumber() {
        // Create a new Departments object with negative department number
        Departments department = new Departments("Emergency Medicine", 106);
        // Verify that setting an empty department name results in an IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            department.setDepartmentNumber(-105);
        });
    }
}
