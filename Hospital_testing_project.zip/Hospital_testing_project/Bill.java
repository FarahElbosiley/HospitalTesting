package com.mycompany.testing_project;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Bill {
    private List<String[]> bills;
    private static final String FILE_NAME = "D:/Bills.txt"; // Path to the bills file

    public Bill() {
        bills = new ArrayList<>();
        loadBillsFromFile("D:/Bills.txt");

    }

    public void loadBillsFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String[] billInfo = new String[]{parts[0], parts[1], parts[2], parts[3]};
                    bills.add(billInfo);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading bills: " + e.getMessage());
        }
    }

    public void addBill(String[] billInfo) {
        bills.add(billInfo);
    }

    public boolean removeBill(String patientID) {
        for (int i = 0; i < bills.size(); i++) {
            if (bills.get(i)[0].equals(patientID)) {
                bills.remove(i);
                return true;
            }
        }
        return false;
    }

    public List<String[]> getAllBills() {
        return bills;
    }

    public void saveBillsToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (String[] bill : bills) {
                String line = String.join(",", bill);
                writer.write(line);
                writer.newLine();
            }
            JOptionPane.showMessageDialog(null, "Bills saved successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving bills: " + e.getMessage());
        }
    }
}
