package com.mycompany.testing_project;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.SwingUtilities;

public class ServicesGUI extends JFrame {

    private JTable jTable1;
    private ArrayList<Services> services;

    public ServicesGUI() {
        initComponents();
        setLocationRelativeTo(null);
        services = new ArrayList<>();
        loadServicesData();
        displayServicesData();
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Services Management");

        jTable1 = new JTable();
        JScrollPane jScrollPane1 = new JScrollPane(jTable1);

        JButton addButton = new JButton("Add Service");
        addButton.addActionListener(e -> addService());

        JButton updateButton = new JButton("Update Service");
        updateButton.addActionListener(e -> {
            String serviceID = selectService();
            if (serviceID != null) {
                int serviceIdToUpdate = Integer.parseInt(serviceID);
                updateService(serviceIdToUpdate);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a service to update.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton removeButton = new JButton("Remove Service");
        removeButton.addActionListener(e -> {
            String serviceID = selectService();
            if (serviceID != null) {
                String confirmMessage = "Are you sure you want to remove the service with ID " + serviceID + "?";
                int option = JOptionPane.showConfirmDialog(this, confirmMessage, "Confirm Removal", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    removeService(Integer.parseInt(serviceID));
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a service to remove.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3));
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(removeButton);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);
        getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);

        pack(); // Pack components
        setVisible(true); // Make frame visible
    }

    private void displayServicesData() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Service ID");
        model.addColumn("Service Name");
        model.addColumn("Service Date");
        model.addColumn("Patient ID");
        model.addColumn("Patient Name");
        model.addColumn("Service Charges");

        for (Services service : services) {
            Object[] rowData = {service.getServiceId(), service.getServiceName(), service.getServiceDate(),
                                service.getPatientId(), service.getPatientName(), service.getServiceCharges()};
            model.addRow(rowData);
        }

        jTable1.setModel(model);
    }

    private void loadServicesData() {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/services.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] serviceInfo = line.split(",");
                if (serviceInfo.length == 7) { // Ensure correct number of fields
                    int serviceID = Integer.parseInt(serviceInfo[0].trim());
                    String serviceName = serviceInfo[1].trim();
                    String serviceDate = serviceInfo[2].trim();
                    int patientID = Integer.parseInt(serviceInfo[3].trim());
                    String patientName = serviceInfo[4].trim();
                    double serviceCharges = Double.parseDouble(serviceInfo[5].trim());
                    int departmentNumber = Integer.parseInt(serviceInfo[6].trim());

                    Services service = new Services(serviceID, serviceName, serviceDate, patientID, patientName, serviceCharges, departmentNumber);
                    services.add(service);
                } else {
                    System.out.println("Invalid record format: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error reading services data: " + e.getMessage());
        }
    }

    private void saveServicesData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/services.txt"))) {
            for (Services service : services) {
                String line = service.getServiceId() + "," + service.getServiceName() + "," + service.getServiceDate()
                            + "," + service.getPatientId() + "," + service.getPatientName() + "," + service.getServiceCharges()+","+service.getDepartmentNumber();
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving services data: " + e.getMessage());
        }
    }

    private String selectService() {
        String[] serviceIDs = services.stream().map(serv -> String.valueOf(serv.getServiceId())).toArray(String[]::new);
        return (String) JOptionPane.showInputDialog(this, "Select a service:", "Select Service",
                                                    JOptionPane.PLAIN_MESSAGE, null, serviceIDs, null);
    }

private void addService() {
    String serviceIdInput = JOptionPane.showInputDialog(this, "Enter Service ID:");
    String serviceName = JOptionPane.showInputDialog(this, "Enter Service Name:");
    String serviceDate = JOptionPane.showInputDialog(this, "Enter Service Date:");
    String patientIDInput = JOptionPane.showInputDialog(this, "Enter Patient ID:");
    String patientName = JOptionPane.showInputDialog(this, "Enter Patient Name:");
    String serviceChargesInput = JOptionPane.showInputDialog(this, "Enter Service Charges:");
    String DepartmentNumberInput = JOptionPane.showInputDialog(this, "Enter Department Number:");

    

    if (serviceIdInput != null && !serviceIdInput.isEmpty() &&
            serviceName != null && !serviceName.isEmpty() &&
            serviceDate != null && !serviceDate.isEmpty() &&
            patientIDInput != null && !patientIDInput.isEmpty() &&
            patientName != null && !patientName.isEmpty() &&
            serviceChargesInput != null && !serviceChargesInput.isEmpty()&&
           DepartmentNumberInput !=null ) {
        int serviceId = Integer.parseInt(serviceIdInput);
        int patientID = Integer.parseInt(patientIDInput);
        double serviceCharges = Double.parseDouble(serviceChargesInput);
        int DepartmentNumber = Integer.parseInt(DepartmentNumberInput);
        

        boolean serviceExists = services.stream().anyMatch(serv -> serv.getServiceId() == serviceId);
        if (!serviceExists) {
            Services service = new Services(serviceId, serviceName, serviceDate, patientID, patientName, serviceCharges, DepartmentNumber);
            services.add(service);
            saveServicesData();
            displayServicesData();
            JOptionPane.showMessageDialog(this, "Service added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Service ID already exists. Please choose a different ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please enter valid input for all fields.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void removeService(int serviceID) {
    boolean removed = false;
    Iterator<Services> iterator = services.iterator();
    while (iterator.hasNext()) {
        Services service = iterator.next();
        if (service.getServiceId() == serviceID) {
            iterator.remove(); // Remove the service from the list
            removed = true;
            break; // Exit the loop after finding and removing the service
        }
    }

    if (removed) {
        saveServicesData();
        displayServicesData();
        JOptionPane.showMessageDialog(this, "Service removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "No service found with ID: " + serviceID, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void updateService(int serviceIdToUpdate) {
    for (Services service : services) {
        if (service.getServiceId() == serviceIdToUpdate) {
            String serviceName = JOptionPane.showInputDialog(this, "Enter Service Name:", service.getServiceName());
            String serviceDate = JOptionPane.showInputDialog(this, "Enter Service Date:", service.getServiceDate());
            String patientIDInput = JOptionPane.showInputDialog(this, "Enter Patient ID:", service.getPatientId());
            String patientName = JOptionPane.showInputDialog(this, "Enter Patient Name:", service.getPatientName());
            String serviceChargesInput = JOptionPane.showInputDialog(this, "Enter Service Charges:", service.getServiceCharges());

            if (serviceName != null && !serviceName.isEmpty() &&
                    serviceDate != null && !serviceDate.isEmpty() &&
                    patientIDInput != null && !patientIDInput.isEmpty() &&
                    patientName != null && !patientName.isEmpty() &&
                    serviceChargesInput != null && !serviceChargesInput.isEmpty()) {
                int patientID = Integer.parseInt(patientIDInput);
                double serviceCharges = Double.parseDouble(serviceChargesInput);

                // Update the service details
                service.setServiceName(serviceName);
                service.setServiceDate(serviceDate);
                service.setPatientId(patientID);
                service.setPatientName(patientName);
                service.setServiceCharges(serviceCharges);

                saveServicesData();
                displayServicesData();
                JOptionPane.showMessageDialog(this, "Service updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                return;
            } else {
                JOptionPane.showMessageDialog(this, "Please enter valid input for all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
    }
    JOptionPane.showMessageDialog(this, "No service found with ID: " + serviceIdToUpdate, "Error", JOptionPane.ERROR_MESSAGE);
}
public static void main(String[] args) {
        // Create an instance of ServicesGUI to start the application
        SwingUtilities.invokeLater(() -> new ServicesGUI());
    }

}