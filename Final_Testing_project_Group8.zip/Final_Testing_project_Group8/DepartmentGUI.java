import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DepartmentGUI extends JFrame {

    private List<Services> services;
    private List<Doctor> doctors;

    private JTable servicesTable;
    private JTable doctorsTable;

    private JButton showServicesButton;
    private JButton showDoctorsButton;
    private JTextField departmentNumberField;

    public DepartmentGUI() {
        setTitle("Department Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        services = new ArrayList<>();
        doctors = new ArrayList<>();

        initComponents();

        loadServicesData("D:/services.txt");
        loadDoctorsData("D:/doctors.txt");

        displayServicesData();
        displayDoctorsData();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        showServicesButton = new JButton("Show Services");
        showDoctorsButton = new JButton("Show Doctors");
        departmentNumberField = new JTextField(10);

        showServicesButton.addActionListener(e -> {
            String departmentNumber = departmentNumberField.getText();
            if (!departmentNumber.isEmpty()) {
                displayServicesByDepartment(departmentNumber);
            }
        });

        showDoctorsButton.addActionListener(e -> {
            String departmentNumber = departmentNumberField.getText();
            if (!departmentNumber.isEmpty()) {
                displayDoctorsByDepartment(departmentNumber);
            }
        });

        servicesTable = new JTable();
        doctorsTable = new JTable();

        JScrollPane servicesScrollPane = new JScrollPane(servicesTable);
        JScrollPane doctorsScrollPane = new JScrollPane(doctorsTable);

        JPanel controlPanel = new JPanel();
        controlPanel.add(new JLabel("Department Number:"));
        controlPanel.add(departmentNumberField);
        controlPanel.add(showServicesButton);
        controlPanel.add(showDoctorsButton);

        mainPanel.add(servicesScrollPane, BorderLayout.CENTER);
        mainPanel.add(doctorsScrollPane, BorderLayout.EAST);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
        setLocationRelativeTo(null); // Center the frame on the screen
    }

    private void loadServicesData(String fileName) {
        services.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 7) { // Check if line has at least 7 fields (0 to 6 indices)
                    int serviceId = Integer.parseInt(parts[0]);
                    String serviceName = parts[1];
                    String serviceDate = parts[2]; // Parse date from string
                    int patientId = Integer.parseInt(parts[3]);
                    String patientName = parts[4];
                    double serviceCharges = Double.parseDouble(parts[5]);
                    int departmentNumber = Integer.parseInt(parts[6]); // Correct index for departmentNumber
                    Services service = new Services(serviceId, serviceName, serviceDate, patientId, patientName, serviceCharges, departmentNumber);
                    services.add(service);
                } else {
                    System.err.println("Invalid service data: " + line);
                }
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error loading services data: " + e.getMessage());
        }
    }

    private void displayServicesData() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Service ID");
        model.addColumn("Service Name");
        model.addColumn("Service Date");
        model.addColumn("Patient ID");
        model.addColumn("Patient Name");
        model.addColumn("Service Charges");
        model.addColumn("Department Number");
        for (Services service : services) {
            model.addRow(new Object[]{service.getServiceId(), service.getServiceName(), service.getServiceDate(), service.getPatientId(), service.getPatientName(), service.getServiceCharges(), service.getDepartmentNumber()});
        }
        servicesTable.setModel(model);
    }

    private void displayServicesByDepartment(String departmentNumber) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Service ID");
        model.addColumn("Service Name");
        model.addColumn("Service Date");
        model.addColumn("Patient ID");
        model.addColumn("Patient Name");
        model.addColumn("Service Charges");
        model.addColumn("Department Number");
        for (Services service : services) {
            if (service.getDepartmentNumber() == Integer.parseInt(departmentNumber)) {
                model.addRow(new Object[]{service.getServiceId(), service.getServiceName(), service.getServiceDate(), service.getPatientId(), service.getPatientName(), service.getServiceCharges(), service.getDepartmentNumber()});
            }
        }
        servicesTable.setModel(model);
    }

    private void loadDoctorsData(String fileName) {
        doctors.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    int doctorId = Integer.parseInt(parts[0]);
                    String doctorName = parts[1];
                    String specialty = parts[2];
                    String departmentNumber = parts[3];
                    Doctor doctor = new Doctor(doctorId, doctorName, specialty, departmentNumber);
                    doctors.add(doctor);
                } else {
                    System.err.println("Invalid doctor data: " + line);
                }
            }
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error loading doctors data: " + e.getMessage());
        }
    }

    private void displayDoctorsData() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Doctor ID");
        model.addColumn("Doctor Name");
        model.addColumn("Specialty");
        model.addColumn("Department Number");
        for (Doctor doctor : doctors) {
            model.addRow(new Object[]{doctor.getDoctorID(), doctor.getDoctorName(), doctor.getSpecialty(), doctor.getDepartmentNumber()});
        }
        doctorsTable.setModel(model);
    }

    private void displayDoctorsByDepartment(String departmentNumber) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Doctor ID");
        model.addColumn("Doctor Name");
        model.addColumn("Specialty");
        model.addColumn("Department Number");
        for (Doctor doctor : doctors) {
            if (doctor.getDepartmentNumber().equals(departmentNumber)) {
                model.addRow(new Object[]{doctor.getDoctorID(), doctor.getDoctorName(), doctor.getSpecialty(), doctor.getDepartmentNumber()});
            }
        }
        doctorsTable.setModel(model);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DepartmentGUI().setVisible(true);
        });
    }
}
